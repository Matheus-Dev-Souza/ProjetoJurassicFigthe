package strategy;

public interface IAtaquebasico {
	float atacar(float forca);
}
