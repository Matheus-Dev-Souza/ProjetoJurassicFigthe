package strategy;

public interface IAtaqueElementa {
	float atacarEspecial(float forca);
}
