package jogador;

public class App {

	public static void main(String[] args) {
		Jogador j1 = new Jogador();
		j1.iniciarLutar();
		j1.informacaoPensonagem();
		
		System.out.println("%%%%%%%%%%%%%%%%%%%");
		System.out.println("%%%%%%%%%%%%%%%%%%%");
		
		j1.iniciarLutar();
	}

}
