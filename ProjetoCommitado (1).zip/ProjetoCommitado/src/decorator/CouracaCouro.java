package decorator;
public class CouracaCouro extends Componentes{
    public CouracaCouro(Armadura armadura){
        super(armadura);
        this.nome="couraça Couro";
        this.forca=1f;
        this.defesa=1f;
        this.velocidade=1f;
        this.life=20f;
        this.valor=10f;
    }
}