package decorator;
public class CouracaOuro extends Componentes{
    public CouracaOuro(Armadura armadura) {
		super(armadura);
        this.nome="couraça Ouro dos irmaos ruda";
        this.forca=1f;
        this.defesa=1f;
        this.velocidade=1f;
        this.life=20f;
        this.valor=30f;
    }
}