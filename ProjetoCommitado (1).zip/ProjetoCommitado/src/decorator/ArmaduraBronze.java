package decorator;
public class ArmaduraBronze extends Armadura {

	public ArmaduraBronze() {
		this.nome = "ArmaduraBronze";
		this.forca = 15f;
		this.defesa = 15f;
		this.velocidade = 15f;
		this.life = 15f;
		this.valor = 20f;
	}

}
