package decorator;
public class ArmaduraCouro extends Armadura{
    public ArmaduraCouro(){
        this.nome="Armadura base";
        this.forca=10f;
        this.defesa=5f;
        this.velocidade=0.1f;
        this.valor=10f;
        this.life=10f;
    }
}