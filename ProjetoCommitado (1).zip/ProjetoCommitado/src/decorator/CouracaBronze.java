package decorator;
public class CouracaBronze extends Componentes{
    public CouracaBronze(Armadura armadura){
        super(armadura);
        this.nome=" couraça Bronze ";
        this.forca=1f;
        this.defesa=1f;
        this.velocidade=1f;
        this.life=20f;
        this.valor=30f;

    }
}