package decorator;
public class ArmaduraOuro extends Armadura {

	public ArmaduraOuro( ) {
		this.nome = "Armadura de ouro";
		this.forca = 25f;
		this.defesa = 25f;
		this.velocidade = 5f;
		this.life = 29f;
		this.valor = 30f;
	}

}