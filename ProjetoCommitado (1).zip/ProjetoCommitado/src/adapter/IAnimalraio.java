package adapter;
public interface IAnimalraio{
    void chidore(float forca);
    void raiosvelozes(float forca);
   
}
