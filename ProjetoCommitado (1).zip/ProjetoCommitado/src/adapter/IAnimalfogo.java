package adapter;
public interface IAnimalfogo{
    void chamasdoexilio(float forca);
    void ataqueflamenjante(float forca);
  
}

