package adapter;
public interface IAnimalvento{
    void ventania(float forca);
    void furacao(float forca);
 
        
}
