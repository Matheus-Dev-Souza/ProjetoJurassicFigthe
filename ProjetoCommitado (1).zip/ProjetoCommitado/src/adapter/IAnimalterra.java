package adapter;
public interface IAnimalterra{
    void ataqueTerra(float forca);
    void terremoto(float forca);
   
}