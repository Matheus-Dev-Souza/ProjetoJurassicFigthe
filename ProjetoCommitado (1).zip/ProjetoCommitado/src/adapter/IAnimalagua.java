package adapter;
public interface IAnimalagua{
    void furiaPosedon(float forca);
    void ataqueElementaragua(float forca);
   
}