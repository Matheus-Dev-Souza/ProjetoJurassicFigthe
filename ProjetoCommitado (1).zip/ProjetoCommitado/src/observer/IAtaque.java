package observer;

public interface IAtaque {
	 void addAtaque(ILutador lutador);
	 void rmAtaque(ILutador lutador);
	 void notificarAtaque();
}
