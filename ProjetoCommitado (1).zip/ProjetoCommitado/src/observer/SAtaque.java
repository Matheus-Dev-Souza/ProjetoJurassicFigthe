package observer;

import java.util.ArrayList;
import java.util.List;

public class SAtaque implements IAtaque {
	private List<ILutador> lutadores = new ArrayList<>();
	private MoldeAtaque ataque = new MoldeAtaque();

	@Override
	public void addAtaque(ILutador ataque) {
		lutadores.add(ataque);
		
	}
	
	@Override
	public void rmAtaque(ILutador ataq) {
		lutadores.remove(ataq);
		
	}

	@Override
	public void notificarAtaque() {
		for(ILutador l : lutadores) {
			l.update(ataque);
		}	
	}
	
	public void setAtaque(MoldeAtaque ataq) {
		this.ataque = ataq;
	}

	

}