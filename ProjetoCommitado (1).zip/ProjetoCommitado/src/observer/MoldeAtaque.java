package observer;

public class MoldeAtaque {
	private String nome;
	private double impactoAtaque;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getImpactoAtaque() {
		return impactoAtaque;
	}
	public void setImpactoAtaque(double impactoAtaque) {
		this.impactoAtaque = impactoAtaque;
	}

}
