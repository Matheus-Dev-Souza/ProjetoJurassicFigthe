package observer;

import strategy.Raposa;

public class AppObserver {
	public static void main(String[] args) {
		
		SAtaque ataque = new SAtaque();
		//nome do ataque, inst�ncia ataque, Animal
		@SuppressWarnings("unused")
		SLutador lutador = new SLutador("ATAQUE ESPECIAL",ataque, new Raposa());
		
		//setar ataque
		MoldeAtaque ataca = new MoldeAtaque();
		ataca.setImpactoAtaque(10);
		ataca.setNome("Especial da Raposa");
	
		ataque.setAtaque(ataca);
		ataque.notificarAtaque();
	}
}
