package observer;

public interface ILutador {
	void update(MoldeAtaque at);
}
