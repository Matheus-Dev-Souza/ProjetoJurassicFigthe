package observer;

import strategy.AnimaisPre;

public class SLutador implements ILutador{
	private String nomeDoAtaque;
	private AnimaisPre anima;
	
	public SLutador(String nomeA, IAtaque ataque, AnimaisPre animalApp) {
		this.nomeDoAtaque=nomeA;
		this.anima = animalApp;
		ataque.addAtaque(this);
	}
	
	
	@Override
	public void update(MoldeAtaque pe) {
		System.out.println("Observer");
		System.out.println("XXXXX=====================================XXX");
		System.out.println(anima.getNome() + " bateu com " + nomeDoAtaque );
		System.out.println("XXXXX=====================================XXX");
	}


	

}
